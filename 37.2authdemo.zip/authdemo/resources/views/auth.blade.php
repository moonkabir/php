@auth
  You are Logged In as {{ Auth::user()->name }}
  You are Logged In as {{ Auth::user()->email }}
@endauth

@guest
    Hellow Guest
@endguest

<p>
    common section 
</p>