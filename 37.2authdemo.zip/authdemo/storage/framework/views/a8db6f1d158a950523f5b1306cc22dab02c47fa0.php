<?php if(auth()->guard()->check()): ?>
  You are Logged In as <?php echo e(Auth::user()->name); ?>

  You are Logged In as <?php echo e(Auth::user()->email); ?>

<?php endif; ?>

<?php if(auth()->guard()->guest()): ?>
    Hellow Guest
<?php endif; ?>

<p>
    common section 
</p><?php /**PATH C:\Users\Moon Kabir\Desktop\laravel\authdemo\resources\views/auth.blade.php ENDPATH**/ ?>