<?php 
namespace App\Model;
class User {
    function sayHi(){
        return "hi";
    }
}