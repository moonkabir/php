<?php
require "vendor/autoload.php";
$connectionParams = array(
    'dbname'   => 'moon',
    'user'     => 'root',
    'password' => '',
    'host'     => '127.0.0.1',
    'driver'   => 'mysqli',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection( $connectionParams );
$qb = $conn->createQueryBuilder();
try {
    if ( $conn->connect() ) {
        /* $qb->insert('moon')
        ->values(['name'=>'?','email'=>'?'])
        ->setParameter(1,'Jimmy Doe')
        ->setParameter(2,'jimmy@doe.com')
        ->execute(); */

        /* $qb->update('moon')
        ->set('email','?')
        ->where('id = ?')
        ->setParameter(1,'jimmy@jimmy.com')
        ->setParameter(2,5)
        ->execute(); */

        $qb->delete('moon')
        ->where('id = ?')
        ->setParameter(1,5)
        ->execute();
    }
} catch ( Exception $e ) {
    echo $e->getMessage();
    echo "Failed";
}