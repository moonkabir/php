<?php
require "vendor/autoload.php";
$connectionParams = array(
    'dbname'   => 'moon',
    'user'     => 'root',
    'password' => '',
    'host'     => '127.0.0.1',
    'driver'   => 'mysqli',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection( $connectionParams );
try {
    if ( $conn->connect() ) {
        $conn->insert('persons',['name'=>'Jim Doe','email'=>'jim@doe.com']);
        echo $conn->lastInsertId();
    }
} catch ( Exception $e ) {
    echo "Failed";
}
// data base ta thik kore table numberta thik kore diye dite hoibo