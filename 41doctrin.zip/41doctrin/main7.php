<?php
require "vendor/autoload.php";
$connectionParams = array(
    'dbname'   => 'moon',
    'user'     => 'root',
    'password' => '',
    'host'     => '127.0.0.1',
    'driver'   => 'mysqli',
);
$conn = \Doctrine\DBAL\DriverManager::getConnection( $connectionParams );
$qb = $conn->createQueryBuilder();
try {
    if ( $conn->connect() ) {
        $qb->select('*')->from('moon')->setMaxResults(10);
        echo $qb->getSQL().PHP_EOL;
        $result = $qb->execute()->fetchAll();
        print_r($result);
    }
} catch ( Exception $e ) {
    echo $e->getMessage();
    echo "Failed";
}