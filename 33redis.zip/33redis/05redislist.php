<?php
require "vendor/autoload.php";
$redis = new Predis\Client();
// $redis ->rpush('chatroom','Jhesyny:We ');

// $redis->rpop('chatroom');
$length = $redis->llen('chatroom');
print_r($redis->lrange('chatroom',0,$length));
// last theke delete 
$redis->lpop('chatroom');