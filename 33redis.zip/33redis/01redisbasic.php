<?php
// use Predis\Client;
require "vendor/autoload.php";
$redis = new Predis\Client();

// $redis->set("key",10,"EX",30);//expire in 30 sec 
// $redis->expire("key",30);//expire in 30 sec 
// echo $redis->get("key");

// -----array pass korte chaile-----
$redis->set("user1",json_encode(['name'=>'Jhon Doe','email'=>'jhon@doe.com']));
print_r(json_decode($redis->get("user1"),true));


//------another example with register---------
// Predis\Autoloader::register();
// $client = new Predis\Client();
// $client->set('foo', 'bar');
// $value = $client->get('foo');
// echo $value; 