<?php
require "vendor/autoload.php";
$redis = new Predis\Client();
$car = [
    'name'=>'sunny',
    'build'=>'2004',
    'company'=>'nissan',
];
// $redis->hset('car01','name','sunny');
// $redis->hset('car01','build','2004');
// $redis->hset('car01','company','nissan');
// echo $redis->hget('car01','name');
// echo $redis->hset('car01','build','2005');//update
// echo $redis->hdel('car01','build');//delete
// echo PHP_EOL;
// print_r( $redis->hgetall('car01'));

// all data insert at a time
$redis->hmset('car01',$car);
print_r( $redis->hgetall('car01'));