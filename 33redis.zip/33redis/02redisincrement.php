<?php
require "vendor/autoload.php";
$redis = new Predis\Client();

// $redis->set("key",10);
// echo $redis->get("key");
// echo PHP_EOL;

// $redis->incr("key");//increment by 1
// echo $redis->get("key");
// echo PHP_EOL;

$redis->incrby("key",5);//increment by 5
echo $redis->get("key");

// --------- decr and decrby ai duita decrement korar jonno------- 