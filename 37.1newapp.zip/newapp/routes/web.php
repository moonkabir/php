<?php

use App\Http\Controllers\formController;
use App\Http\Controllers\friends;
use App\Http\Controllers\MainController;
use App\Http\Controllers\postsController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

// Route::get('/hello/world','MainController@sayHi');
Route::get('/hello/world',[MainController::class,'sayHi']);
Route::get('/sayname/{name}',[MainController::class,'sayMyName']);
// Route::post('/sayname/{name}',[MainController::class,'postRequest']);

Route::get('/hellow/{world}', function ($world) {
    return view("info",[
        'name'=>$world
    ]);
});

Route::get('/me',function(){
    return ['name'=>'Moon'];
});

Route::get('/hellow/{name}', function ($newWorld) {
    return "welcome, hellow {$newWorld}";
});

Route::post('/say',function(Request $request){
    $newName = $request->post('name');
    echo "hellow {$newName}";
});

// Route::get('/',[MainController::class,'main']);
Route::get('/features',[MainController::class,'features']);
Route::get('/contact',[MainController::class,'contact']);
Route::get('/allpeople',[MainController::class,'allpeople']);
Route::get('/testmodel',[MainController::class,'testmodel']);
Route::get('/form',[formController::class,'displayForm'])->name("form.create");
Route::post('/save',[formController::class,'saveForm'])->name("form.save");
Route::get('/',[postsController::class,'createPost'])->name('posts.create');