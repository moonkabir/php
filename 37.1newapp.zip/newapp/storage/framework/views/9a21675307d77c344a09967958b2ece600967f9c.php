<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>This is my Fisrt Application</h1>
    <p>Hellow <strong> <?php echo e($name); ?> </strong></p>
</body>
</html><?php /**PATH C:\Users\Moon Kabir\Desktop\laravel\newapp\resources\views/info.blade.php ENDPATH**/ ?>