
<?php $__env->startSection('body'); ?>
    <main role="main" class="inner cover">
        <h1 class="cover-heading">Features.</h1>
        <p class="lead">Cover is a one-page template for building simple and beautiful home pages. Download, edit the text, and add your own fullscreen background photo to make it your own.</p>
        <p class="lead">
            <a href="#" class="btn btn-lg btn-secondary">Learn more</a>
        </p>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Moon Kabir\Desktop\laravel\newapp\resources\views/features.blade.php ENDPATH**/ ?>