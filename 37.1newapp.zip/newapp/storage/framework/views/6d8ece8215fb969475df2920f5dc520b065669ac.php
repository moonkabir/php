
<?php $__env->startSection('body'); ?>
    <main role="main" class="inner cover">
        <h1 class="cover-heading"> Add Person</h1>
    <form method="post" action="<?php echo e(route("form.save")); ?>">
            <div class="form-group">
                <?php echo csrf_field(); ?>
                <label for="name">Name:</label>
                <input type="text" class="form-control" name="name"/>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" name="email"/>
            </div>
            <button type="submit" class="btn btn-primary"> Add Person</button>
        </form>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Moon Kabir\Desktop\laravel\newapp\resources\views/form.blade.php ENDPATH**/ ?>