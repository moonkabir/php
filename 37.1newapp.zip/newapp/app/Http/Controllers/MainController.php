<?php

namespace App\Http\Controllers;
use App\people;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class MainController extends Controller
{
    function sayHi(){
        return "Hello World from the controller";
    }
    function sayMyName($name){
        return "Hello {$name}";
    }

    // function postRequest(Request $request){
    //     $Name = $request->post('name');
    // }

    function main(){
        return view("newWelcome");
    }
    function features(){
        return view("features");
    }
    function contact(){
        return view("contact");
    }
    function allpeople(){
        // return((array) DB::table('people')->where('id',1)->first());
        return(DB::table('people')
                ->where('id',1)
                ->limit(1)
                // ->get());//all value chaile
                ->get(['id','name']));
        // return(DB::select('select id,name from people));
    }
    
    function testmodel(){
        // $people = people::all();
        // $people = people::whereEmail('jhon@doe.com')->first();//where er sathe column er nam ta add kore dilei hobe 
        // $people = people::whereName('Jhon Doe')->first()->displayNameAndEmail();

        /* data update
        $people = people::find(1);
        $people->name = "Jhon Doe";
        $people->save();
        $people = $people->fresh();*/

        // $people = people::find(1);
        // $people->addJr();
        // $people->fresh();
        
        $people = people::find(1);
        $posts = $people->posts;

        return $posts;
    }





}
