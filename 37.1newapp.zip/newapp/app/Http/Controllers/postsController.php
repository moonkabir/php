<?php

namespace App\Http\Controllers;
use App\post;
use Illuminate\Http\Request;

class postsController extends Controller
{
    function createPost(){
        $post = new post();
        $post->title = "Quick Brown Fox";
        $post->content = "Jumps Over the Lazy Dog";
        $post->save();
        return $post;
    }
}
