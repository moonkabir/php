<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use PDO;

class people extends Model
{
    protected $fillable = ['name','email'];
    
    function displayNameAndEmail(){
        echo $this->name ." : ".$this->email;
    }
    function addJr(){
        echo $this->name .= "  Jr" ;
    }
    function posts(){
        return $this->hasMany(\App\Post::class);
    }
}
